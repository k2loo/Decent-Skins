#### FUNDAMENTAL and VCVRACK ####

All Fundamental and VCV Rack source code excerpts used in Impromptu Modular are copyright © 2016-2021 Andrew Belt and are licensed under the GNU General Public License v3.0 or later.


#### AUDIBLE INSTRUMENTS ####

All Audible Instruments source code excerpts used in Impromptu Modular are copyright © 2016-2021 Andrew Belt and Audible Instruments contributers and are licensed under the GNU General Public License v3.0 or later.


#### BLANK PANEL ####

The lightning svg used to make the Blank panel has the following license :

http://www.supercoloring.com/silhouettes/lightning

Author: Natasha Sinegina 

This silhouette is a derivative work (tracing copy). Original image credit: Lightning in Zdolbuniv photo by Lyoha123 

Permission:  Some rights reserved. This work is licensed under a Creative Commons Attribution-Share Alike 4.0 License. 

You are free to share or adapt it for any purpose, even commercially under the following terms: you must give a link to this page and indicate the author's name and the license.