
Uses [FFTReal](https://github.com/cyrilcode/fft-real) under terms of the "Do What The F*ck You Want To Public License": ([https://github.com/cyrilcode/fft-real/blob/master/license.txt](https://github.com/cyrilcode/fft-real/blob/master/license.txt)).
