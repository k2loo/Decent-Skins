## 4ms Company VCV Rack Modules

This software is copyright (c) 2024 4ms Company.

This program is free software: you can redistribute it and/or modify it under
the terms of the GNU General Public License as published by the Free Software
Foundation, either version 3 of the License, or (at your option) any later
version.

See LICENSE-GPL-v3.txt for the text of the license.

The MetaModule name is copyright (c) 2024 4ms Company.

Third-party libraries are licensed by the respective licenses of the copyright
holders, which are included in their respective sub-directories. The files
RackSDK.cmake and Makefile are from https://github.com/baconpaul/airwin2rack/ 
and used under the license at https://github.com/baconpaul/airwin2rack/blob/main/LICENSE.md

