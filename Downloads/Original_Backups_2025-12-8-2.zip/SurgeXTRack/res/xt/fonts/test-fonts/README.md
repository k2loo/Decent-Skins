Fonts in this skin are:

UglyTypist Regular: https://fontlibrary.org/en/font/uglytypist
Released under the OFL

Mrs Beasley Regular: https://fontlibrary.org/en/font/mrs-beasley
Released under the OFL

Playfair Display SC from Google Fonts under OFL
Lobster-Regular from Google Fonts under the OFL
