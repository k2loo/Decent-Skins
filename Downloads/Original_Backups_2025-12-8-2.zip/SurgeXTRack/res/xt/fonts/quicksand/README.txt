QuickSand Open SIL font

Downloaded from https://www.fontsquirrel.com/fonts/quicksand

OTF -> TTF conversion: https://everythingfonts.com/otf-to-ttf
