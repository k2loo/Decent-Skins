Used with the permission of Phil Golden the Author of Coirt / Bark plugins https://vcvrack.com/plugins#Coirt

- BarkSwitchSmall_0.svg
- BarkSwitchSmall_1.svg

- BarkSwitchSmallSide_0.svg
- BarkSwitchSmallSide_1.svg
- BarkSwitchSmallSide_2.svg